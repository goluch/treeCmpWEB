/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package treecmp.spr;

import pal.tree.Node;

/**
 *
 * @author Damian
 */
public class NodeIdPair {
 public NodeIdPair(Node node, String id) {
            this.node = node;
            this.id = id;
        }
        public Node node;
        public String id;
}
