/** This file is part of MCdist, a program for computing the Matching Cluster
    distance between phylogenetic trees.
    Copyright (C) 2011,  Damian Bogdanowicz

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. */

package treecmp.metric;

import java.util.BitSet;
import java.util.Vector;
import pal.misc.IdGroup;
import pal.tree.CladeSystem;
import pal.tree.Node;
import pal.tree.Tree;
import pal.tree.TreeUtils;
import treecmp.common.LapSolver;
import treecmp.metric.BaseMetric;
import treecmp.metric.Metric;

/**
 *
 * @author Damian
 */
public class MatchingClusterMetric extends BaseMetric implements Metric {

    private Vector<Integer> edgeCosts;
    private boolean calcEdgeCosts;

    public boolean isCalcEdgeCosts() {
        return calcEdgeCosts;
    }

    public Vector<Integer> getEdgeCosts() {
        return edgeCosts;
    }

    public void setCalcEdgeCosts(boolean calcEdgeCosts) {
        this.calcEdgeCosts = calcEdgeCosts;
    }

    public void clearCalcEdgeCosts() {
        edgeCosts.clear();
    }

    public MatchingClusterMetric() {
        super();
        calcEdgeCosts = false;
        edgeCosts = new Vector<Integer>();
    }

    public double getDistance(Tree t1, Tree t2) {
        //  long start = System.currentTimeMillis();

        int i, j;
        int metric, w;
        IdGroup idGroup = TreeUtils.getLeafIdGroup(t1);

        BitSet[] bs1 = ClusterDist.RootedTree2BitSetArray(t1, idGroup);
        BitSet[] bs2 = ClusterDist.RootedTree2BitSetArray(t2, idGroup);

        int size1 = bs1.length;
        int size2 = bs2.length;

        int size = Math.max(size1, size2);
        if (size <= 0) {
            return 0;
        }

        int n = t1.getExternalNodeCount();
        int[][] assigncost = new int[size][size];
        int[] rowsol = new int[size];
        int[] colsol = new int[size];
        int[] u = new int[size];
        int[] v = new int[size];

        if (size1 > size2) {
            for (i = 0; i < size1; i++) {
                for (j = 0; j < size2; j++) {
                    assigncost[i][j] = ClusterDist.getDistXorBit(bs1[i], bs2[j]);
                }
                for (j = size2; j < size1; j++) {
                    assigncost[i][j] = ClusterDist.getDistToOAsMinBit(bs1[i]);
                }
            }
        } else {
            for (i = 0; i < size2; i++) {
                for (j = 0; j < size1; j++) {
                    assigncost[i][j] = ClusterDist.getDistXorBit(bs2[i], bs1[j]);
                }
                for (j = size1; j < size2; j++) {
                    assigncost[i][j] = ClusterDist.getDistToOAsMinBit(bs2[i]);
                }
            }
        }

        metric = LapSolver.lap(size, assigncost, rowsol, colsol, u, v);

        return metric;
    }
}
